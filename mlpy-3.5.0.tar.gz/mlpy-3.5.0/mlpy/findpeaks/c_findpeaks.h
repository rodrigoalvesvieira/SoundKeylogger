#include <stdlib.h>

int *fp_win(double *x, int n, int span, int *m);
